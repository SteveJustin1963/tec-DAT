

    LC2D Graphics Library for Hitachi Controller based Character LCDs!

                              V2 - 18/10/13

                      (c) Brek Martin (Art) 2013.
                PicBASIC Pro 2.50 - Compiled with MPASM
             Demo Program for Microchip Pic 16F628 @ 8 MHz


Hi Guys,

LC2D is a 2D graphics program with included 2D drawing routines for Hitachi
controller based character LCDs such as 2x16 character displays used in the
YouTube video demo, with PicBASIC Pro compiler for Pic microcontrollers.

LC2D provides for the use of a 24x17 pixel graphics display that is easy to
use without having to think about the LCD or custom character RAM at all.
This makes it possible to directly reference a screen with pixel coordinates
for drawing, and should make graphics tricks such as bargraph/odometer/scroll
effects easier with these LCDs that were not designed for graphics.
To the point, you can talk to the LCD as you would talk to a GLCD!


Disclaimer:

This software is provided as is, with the intention to serve a purpose.
The author accepts no responsibility with regard to lack of suitability,
damages, loss of life, data, things going up in smoke, or anything else.


Lisence:

LC2D is free for personal (non-commercial) use. If you have other use in mind,
please contact the author: bushprogrammer@gmail.com

This package may be freely distributed, and hosted, provided that the package
remains intact, unmodified, and containing this documentation.

This project is not GPL. You may include it in any non-commercial project,
and redistribute that project without providing any source code.
You must include this documentation if you reveal this source code.

2D drawing routines are included for demonstration purposes.
Circle drawing is from a GLCD graphics demo posted on PicBASIC forum by Dave.
Line drawing is ported to PBP unsigned byte variables by the author,
and thanks to oogabooga of C Programming forums for optimisation.

This project lives on MElabs PicBASIC forums, and will be first updated there.


Usage:

I think the demo says it all :)
You may want to set HS_OSC, and Brown Out Detect bits for the 16F628A.
The demo program consumes most of the 16F628A program memory, but when
it is stripped of 2D drawing routines, the bare framebuffer code leaves
about half the memory (program and RAM) free for your own code.
Remove the demo routines, and any drawing routines you don't need,
and there's plenty of room left on the chip for a moderate project.

The program can easily be ported to 16F877, but you'll need to be carefull
about keeping some of the library in the first 2K code page, and variables
in the first RAM bank. There is a single assembler routine in the library
that will not be happy if the screen buffer is not in the first bank.


Changes for Version 2:

Freed up more program space, and RAM, and better performance.
At least ten bytes of RAM is freed from the base code.
This leaves much more resource for your program.
I have filled the extra space and used the extra RAM
for more demo sections, but you can remove that.

The most notible new section being the rolling odometer effect
on the demo counting variable. I ran out of memory before I could
get it working in forward or reverse direction,
so it's only forward direction (variable must be incrementing by one).

Some more demo sections that look a bit more graceful with
the use of the entire LCD display.


Issues / Limitations:

The circle drawing routine doesn't like circles with radius less than 3.
They will mess up the display, possibly never exit, crash, or watchdog reset.

Line drawing routine is not tested where the source and destination are the
same point. This could potentially never exit, crash, or watchdog reset.

There are invisible pixels that will hide some straight lines.
For example, an analogue clock face would otherwise be possible,
but the hands would be hidden at 90 degree intervals.
The physical pixel breaks that occur between characters on the LCD do exist
in memory, and can be set, but not seen. The program checks screen bounds.
It is not possible to crash the chip by writing to the display out of bounds.

The demo circuit is run at 8 MHZ, but the compiler is told the circuit is
running at 4MHz. This will halve the timing of PAUSE and LCDOUT timings.

The serial Rx line in the provided schematic is not implemented in the program
and can be ignored. 


Links:

Hack-A-Day Feature:
http://hackaday.com/2013/10/16/teach-an-old-lcd-new-tricks/

Minimal website:
http://www.freewebs.com/defxev/LC2D.htm

PBP Forum Thread:
http://www.picbasic.co.uk/forum/showthread.php?t=18416


Enjoy!

